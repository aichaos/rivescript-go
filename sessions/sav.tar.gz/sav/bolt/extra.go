package bolt

func (s *MemoryStore) BoltWrite(username string,*sessions.UserData) error {
	d,err:=json.Marshal(data)
	if err != nil  {
		return err
	}
	db.Update(func(tx *bolt.Tx) error {
		err := tx.Bucket(s.prefix).Put(username, d)
		return err
	})
	return nil 
}

func (s *MemoryStore) BoltGet(username string) (val []byte {
	val := s.DB.View(func(tx *bolt.Tx) []byte {
		v := tx.Bucket(s.prefix).Get(username)
	})
	return v
}

func (s *MemoryStore)